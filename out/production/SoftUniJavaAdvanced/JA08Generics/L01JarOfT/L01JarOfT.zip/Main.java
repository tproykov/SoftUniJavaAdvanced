package JA08Generics.L01JarOfT;

public class Main {

    public static void main(String[] args) {

        Jar<String> jarOfTexts = new Jar<>();
    }
}