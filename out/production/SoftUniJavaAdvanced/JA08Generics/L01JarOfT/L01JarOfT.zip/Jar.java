package JA08Generics.L01JarOfT;

import java.util.ArrayDeque;

public class Jar <T> {

    private ArrayDeque<T> stack;

    public Jar() {
        this.stack = new ArrayDeque<>();
    }

    public void add(T element) {
        this.stack.push(element);
    }

    public T remove(T element) {
        stack.pop();
        return this.stack.pop();
    }
}
