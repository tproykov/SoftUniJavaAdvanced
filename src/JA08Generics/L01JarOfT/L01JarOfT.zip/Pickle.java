package JA08Generics.L01JarOfT;

public class Pickle {
}
